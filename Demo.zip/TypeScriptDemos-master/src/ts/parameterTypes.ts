﻿function add(msg: string, x: number, y: number) {
    console.log(msg + (x + y));
}

add('typed parameters (msg: string, x: number, y: number) = ', 3, 2);

 