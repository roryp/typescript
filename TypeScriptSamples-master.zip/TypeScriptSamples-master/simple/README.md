# TypeScript Sample: Simple 

## Overview 

Simple use of classes and inheritance:
- Classes:  A base class and two subclasses 
- Super calls: Derived classes make super calls


## Running 

`tsc --sourcemap animals.ts`
