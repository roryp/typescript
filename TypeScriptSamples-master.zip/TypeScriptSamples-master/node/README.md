# TypeScript Sample: Node.js 

## Overview 

This sample implements a very basic node.js application using TypeScript

## Running 
For HttpServer
```
tsc --sourcemap --module commonjs HttpServer.ts
node HttpServer.js
```

For TcpServer
```
tsc --sourcemap --module commonjs TcpServer.ts
node TcpServer.js
```